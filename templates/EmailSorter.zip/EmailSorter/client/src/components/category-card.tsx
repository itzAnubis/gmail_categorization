import { Link } from "wouter";
import { Category } from "@/lib/categories";
import { 
  Briefcase, 
  Book, 
  User, 
  DollarSign, 
  Plane, 
  Plus,
  ChevronRight 
} from "lucide-react";

interface CategoryCardProps {
  category: Category;
}

// Function to get the icon component based on category type
function getCategoryIcon(type: string) {
  switch (type) {
    case 'work':
      return <Briefcase className="text-primary" />;
    case 'study':
      return <Book className="text-secondary" />;
    case 'personal':
      return <User className="text-accent" />;
    case 'finance':
      return <DollarSign className="text-blue-600" />;
    case 'travel':
      return <Plane className="text-purple-600" />;
    case 'custom':
      return <Plus className="text-gray-400" />;
    default:
      return <Briefcase className="text-primary" />;
  }
}

// Function to get background color based on category type
function getBgColor(type: string) {
  switch (type) {
    case 'work':
      return 'bg-indigo-100';
    case 'study':
      return 'bg-orange-100';
    case 'personal':
      return 'bg-emerald-100';
    case 'finance':
      return 'bg-blue-100';
    case 'travel':
      return 'bg-purple-100';
    case 'custom':
      return 'bg-gray-100';
    default:
      return 'bg-indigo-100';
  }
}

// Function to get text color based on category type
function getTextColor(type: string) {
  switch (type) {
    case 'work':
      return 'text-primary';
    case 'study':
      return 'text-secondary';
    case 'personal':
      return 'text-accent';
    case 'finance':
      return 'text-blue-600';
    case 'travel':
      return 'text-purple-600';
    case 'custom':
      return 'text-gray-700';
    default:
      return 'text-primary';
  }
}

// Function to get progress bar color based on category type
function getProgressColor(type: string) {
  switch (type) {
    case 'work':
      return 'bg-primary';
    case 'study':
      return 'bg-secondary';
    case 'personal':
      return 'bg-accent';
    case 'finance':
      return 'bg-blue-600';
    case 'travel':
      return 'bg-purple-600';
    case 'custom':
      return 'bg-gray-400';
    default:
      return 'bg-primary';
  }
}

export function CategoryCard({ category }: CategoryCardProps) {
  const { id, name, type, description, emailCount, processedPercentage } = category;
  
  if (type === 'custom') {
    return (
      <div className="bg-white overflow-hidden shadow rounded-lg border-2 border-dashed border-gray-300 transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1">
        <div className="p-5 flex flex-col items-center justify-center h-full text-center">
          <div className="rounded-full bg-gray-100 p-3 inline-block">
            <Plus className="text-gray-400 h-6 w-6" />
          </div>
          <h3 className="mt-4 text-lg font-medium text-gray-900">Create Custom Category</h3>
          <p className="mt-2 text-base text-gray-500">
            Create your own custom categories based on your specific needs.
          </p>
          <div className="mt-5">
            <button className="px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 transition-all duration-300">
              Add New Category
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white overflow-hidden shadow rounded-lg transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1">
      <div className="p-5">
        <div className={`rounded-full ${getBgColor(type)} p-3 inline-block`}>
          {getCategoryIcon(type)}
        </div>
        <h3 className="mt-4 text-lg font-medium text-gray-900">{name}</h3>
        <p className="mt-2 text-base text-gray-500">
          {description}
        </p>
        <div className="mt-4">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className={`${getProgressColor(type)} rounded-full h-2`} 
              style={{ width: `${processedPercentage}%` }}
            ></div>
          </div>
          <div className="flex justify-between mt-1 text-sm">
            <span className="text-gray-500">{emailCount} emails</span>
            <span className={`${getTextColor(type)} font-medium`}>{processedPercentage}% processed</span>
          </div>
        </div>
        <div className="mt-5">
          <Link href={`/category/${id}`} className={`${getTextColor(type)} hover:opacity-80 font-medium flex items-center`}>
            View category <ChevronRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
