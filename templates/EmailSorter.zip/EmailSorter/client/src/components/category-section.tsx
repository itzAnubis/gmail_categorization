import { CategoryCard } from "./category-card";
import { categories } from "@/lib/categories";

export default function CategorySection() {
  return (
    <section className="py-12 bg-gray-50 sm:py-16 lg:py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base font-semibold text-primary uppercase tracking-wide">Features</h2>
          <p className="mt-1 text-3xl font-extrabold text-gray-900 sm:text-4xl sm:tracking-tight lg:text-4xl">
            Intelligent Email Categories
          </p>
          <p className="max-w-xl mt-5 mx-auto text-xl text-gray-500">
            Our AI-powered system automatically organizes your emails into intuitive categories
          </p>
        </div>

        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>
    </section>
  );
}
