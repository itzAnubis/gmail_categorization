import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function CtaSection() {
  return (
    <section className="bg-primary">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            <span className="block">Ready to organize your emails?</span>
            <span className="block">Start using EmailOrganizer today.</span>
          </h2>
          <p className="mt-4 text-lg leading-6 text-indigo-100">
            Get started with our free plan. No credit card required.
          </p>
          <div className="mt-8 flex justify-center flex-wrap gap-3">
            <Button 
              asChild
              className="bg-white text-primary hover:bg-indigo-50 transition-all duration-300"
            >
              <Link href="/signup">
                Get started for free
              </Link>
            </Button>
            <Button 
              asChild
              className="bg-indigo-700 text-white hover:bg-indigo-800 transition-all duration-300"
            >
              <Link href="/learn-more">
                Learn more
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
