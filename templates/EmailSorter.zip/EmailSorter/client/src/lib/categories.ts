export interface Category {
  id: string;
  name: string;
  type: 'work' | 'study' | 'personal' | 'finance' | 'travel' | 'custom';
  description: string;
  emailCount: number;
  processedPercentage: number;
}

export const categories: Category[] = [
  {
    id: 'work',
    name: 'Work',
    type: 'work',
    description: 'Keep your professional emails organized by projects, clients, and importance.',
    emailCount: 126,
    processedPercentage: 75
  },
  {
    id: 'study',
    name: 'Study',
    type: 'study',
    description: 'Keep track of course materials, assignments, and educational resources.',
    emailCount: 84,
    processedPercentage: 60
  },
  {
    id: 'personal',
    name: 'Personal',
    type: 'personal',
    description: 'Keep your personal communications separate from work and other categories.',
    emailCount: 158,
    processedPercentage: 90
  },
  {
    id: 'finance',
    name: 'Finance',
    type: 'finance',
    description: 'Track bills, invoices, receipts and financial statements in one place.',
    emailCount: 67,
    processedPercentage: 45
  },
  {
    id: 'travel',
    name: 'Travel',
    type: 'travel',
    description: 'Organize flight confirmations, hotel bookings, and itineraries automatically.',
    emailCount: 42,
    processedPercentage: 30
  },
  {
    id: 'custom',
    name: 'Custom Category',
    type: 'custom',
    description: 'Create your own custom categories based on your specific needs.',
    emailCount: 0,
    processedPercentage: 0
  }
];
