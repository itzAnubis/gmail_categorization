import Header from "@/components/header";
import Footer from "@/components/footer";

export default function Dashboard() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 text-gray-800 font-sans">
      <Header />
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900">Your Email Dashboard</h1>
          <p className="mt-2 text-lg text-gray-600">
            Welcome to your email dashboard. This is where you'll manage and organize your emails.
          </p>
          <div className="mt-8 bg-white p-6 rounded-lg shadow">
            <p className="text-gray-500">Dashboard content will appear here.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}