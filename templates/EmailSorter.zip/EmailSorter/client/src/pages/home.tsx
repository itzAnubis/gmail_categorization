import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import CategorySection from "@/components/category-section";
import StatsSection from "@/components/stats-section";
import CtaSection from "@/components/cta-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 text-gray-800 font-sans">
      <Header />
      <main>
        <HeroSection />
        <CategorySection />
        <StatsSection />
        <CtaSection />
      </main>
      <Footer />
    </div>
  );
}
